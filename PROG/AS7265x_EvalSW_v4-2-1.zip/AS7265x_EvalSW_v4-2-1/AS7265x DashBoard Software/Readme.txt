For AS7265x 


This folder consist of

          - FTDI Virtual COM Port Driver Setup exe file 
          - Dashboard Software - tcl Dashboard Installation file (DashBoard software AS7265x)
          - current AS7265 firmware - Complete 256kb and Update 56kb firmware bin file and AT-command list xlsx file


Note: - PC and Winbdws 32/64 Bit
              ActiveState TCL Run-Time Setup - TCL run time exe file for windows 32 or 64 bit (download from ActiveState TCL site) to run the Dashboard Software 


The AS7265x test system is tightly integrated with its companion firmware, which allows periodic enhancements and updates. Please download the latest version of the datasheet, which includes the current command set and features on the Spectral Sensing Product family page at https://ams.com/upload-center.
Also download User Guide.

User will have to create an account on ams.com (click login -> Create Account) to request the download SW data and relevent documents 

Please read forUser Guide in the documentation set. Then connect the hardware based on our instructions in User Guide  and run the test software.
